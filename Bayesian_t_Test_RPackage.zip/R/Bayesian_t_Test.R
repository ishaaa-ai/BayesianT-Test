#' @title BayesianT-Test
#'
#' @description This package tests for the mean of one and k-sample using
#'              Bayesian methods. The main function bayesian_t_test takes six
#'              parameters. 'a' and 'b' refer to the range of values. 'm1'
#'              and 'm2' are the me
#'
#' @param a
#' @param b
#' @param m1
#' @param m2
#' @param s1
#' @param s2
#'
#' @return NULL
#'
#' @export bayesian_t_test
#'


bayesian_t_test <- function(a,b,m1,m2,s1.sqr,s2.sqr)
{
  #######################
  ## One-sample t-test ##
  #######################

  ## Dental anxiety in adults

  #rm(list=ls(all=TRUE))

  ##model: x1, ...xn~N(mu,sigma^2), where sigma is unknown

  ## Data summary

  n=15 # sample size
  xbar.sample=10.7 # sample mean
  s.sqr.sample=3.6^2 # sample variance

  #Hypothesized value H0: mu=mu1
  mu1=11
  ###############################################
  ## elicitation prior: before seeing the data ##
  ###############################################
  # 1/sigma^2~Gamma(alpha0,beta0)
  # mu~N(mu0,tau0^2*sigma^2)
  # 1/sigma^2~Gamma(alpha0,beta0)
  # mu~N(mu0,tau0^2*sigma^2)

  #### Prior elicitation #####
  #### Evan2 Method      #####
  ############################


  elicit <- function(a,b,s1.sqr,s2.sqr){
    m <- matrix(0,2,1)
    m[1] <- qgamma((1+0.999)/2,a,b) - ((1/s1.sqr)*qnorm((1+.999)/2))^2
    m[2] <- qgamma((1-.999)/2,a,b) - ((1/s2.sqr)*qnorm((1+.999)/2))^2
    return(m=m)
  }

  gamma.par = function(a,b,m1,m2,s1.sqr,s2.sqr)
  {
    x <- matrix(c(a,b),2,1)
    delta <- x
    maxiter <- 1000
    iter <- 0
    tol <- 0.5
    while(norm(delta) > tol & iter < maxiter){
      h <- 0.000000001
      fx <- elicit(x[1],x[2],s1.sqr,s2.sqr)
      Jx <- matrix(0,2,2)
      for(i in 1:2){
        xh <- x
        xh[i] <- x[i] + h
        fxh <- elicit(xh[1],xh[2],s1.sqr,s2.sqr)
        Jx[,i] <- (fxh - fx)/h
      }

      delta <- -solve(Jx) %*% elicit(x[1],x[2],s1.sqr,s2.sqr)

      x <- x + delta
      iter <- iter + 1
    }
    tau0.sq <- (((m2 - m1)/2)^2)/s2.sqr

    mu0 <- (m1+m2)/2
    return(c(x,mu0,tau0.sq))
  }
  x=gamma.par(a,b,m1,m2,s1.sqr,s2.sqr)

  alpha0=x[1]
  beta0=x[2]
  mu0=x[3]
  tau0.sq=x[4]
  tau0=tau0.sq^0.5
  #hyperparameters
  alpha0.prior=alpha0
  beta0.prior=beta0

  cbind(alpha0.prior,beta0.prior, mu0, tau0)




  ########
  # TEST #
  ########
  #distance
  rep=5000
  d.prior=matrix(0,rep,1)#prior distance
  d.post=matrix(0,rep,1) #posterior distance
  RB_dir=matrix(0,rep,1) # RB direct
  strength_dir=matrix(0,rep,1) # strenght direct
  for (i in 1:rep)
  {

    #prior
    var.prior=1/rgamma(1,alpha0.prior,rate=beta0.prior)
    sigma.prior=var.prior^0.5
    mu.prior=rnorm(1,mean=mu0,sd=tau0*sigma.prior) #generate prior mu
    ##  KL distance between  N(mu.prior,sigma^2) to N(mu1,sigma^2)
    ## Here sigma^2 is equal to its mle.
    KL.prior=(mu.prior-mu1)^2/(2*sigma.prior^2)
    KL.prior
    d.prior[i]=KL.prior

    #posteroior
    xbar=rnorm(1,mean=mu.prior,sd=sigma.prior/n^0.5)
    alpha.post=alpha0.prior+(n/2)
    beta.post=beta0.prior+(n-1)*s.sqr.sample/2+n*(xbar-mu0)^2/(2*(n*tau0^2+1))
    var.post.inv=rgamma(1,alpha.post,beta.post)
    sigma.sqr=1/var.post.inv
    mu.x.post=((mu0/tau0^2)+n*xbar.sample)/(n+1/tau0^2)
    var.x.post=sigma.sqr/(n+1/tau0^2)
    sig.x.post=var.x.post^{0.5}
    mu.post=rnorm(1,mean =mu.x.post,sd=sig.x.post)# generate mu post

    ##  KL distance between  N(mu.post,sigma^2) to N(mu1,sigma^2)
    # same s1 and s2 in prior
    ## Here sigma^2 is equal to its mle (same as in the prior)
    KL.post=(mu.post-mu1)^2/(2*sigma.prior^2)
    KL.post
    d.post[i]=KL.post
  }

  ###plots of densities###
  d.prior1=density(d.prior)
  d.post1=density(d.post)
  x.limit=1
  y.limit=8
  plot(d.prior1, main="Kernel Density of distance",lwd = 2,xlim=c(0,x.limit),ylim=c(0,y.limit))
  lines(d.post1,col = 2, lty = 2, lwd = 2)
  legend(.5,4,c("prior", "posterior"), col = c(1,2),text.col = "black",
         lty = c(1, 2),lwd =c(2,2))

  ###Relative Belief Ratio###
  M=20
  #prior quantiles i=0,...,M
  psi.prior=matrix(0,M+1,1)
  psi.prior[1]=0
  for (i in 1:M) psi.prior[i+1]=quantile(d.prior,i/M)
  psi.star=psi.prior[2]# 1/M quantile
  Fn.prior=ecdf(d.prior) # Fn for prior distance
  Fn.post=ecdf(d.post) #Fn for posterior diistance
  RB_dist=Fn.post(psi.star)/Fn.prior(psi.star)
  ###Strength###
  RBR.hat=matrix(0,M,1)
  for (i in 1:M) RBR.hat[i]=M*(Fn.post(psi.prior[i+1])-Fn.post(psi.prior[i]))
  sum0=matrix(0,M,1)
  for (i in 1:M) {if (RBR.hat[i]<=RB_dist) sum0[i]=Fn.post(psi.prior[i+1])-Fn.post(psi.prior[i])}
  strength=sum(sum0)

  #####RESULTS#####
  #New
  New=cbind(RB_dist,strength)
  New

}
